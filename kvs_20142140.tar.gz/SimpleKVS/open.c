#include <stdio.h>

FILE *putP = NULL;
FILE *getP = NULL;

int open()
{
	putP = fopen("put.txt","r");
	if(putP == NULL){
		return -1;
	}

	getP = fopen("get.txt","r");
	if(getP == NULL){
		return -2;
	}
	return 0;
}

