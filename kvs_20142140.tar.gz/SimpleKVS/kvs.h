typedef struct _put pNode;
struct _put{
	pNode *next;
	char key[16];
	char value[99];
};

int put(char *key, char *value, int nbytes);
char *get(char *key, int *nbytes);
int open();
void close();
