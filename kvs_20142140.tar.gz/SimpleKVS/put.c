#include <stdlib.h>
#include <string.h>
#include "kvs.h"

pNode *pHead = NULL;

int put(char* key, char* value, int nbytes)
{
	pNode *new = malloc(sizeof(pNode));
	new->next = pHead->next;
	strcpy(new->key, key);
	strcpy(new->value, value);
	pHead->next = new;
	if(pHead == NULL){
		return -1;
	}
	return 0;
}

