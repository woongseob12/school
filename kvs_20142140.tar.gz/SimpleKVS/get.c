#include <stdlib.h>
#include <string.h>
#include "kvs.h"

extern pNode *pHead;

char* get(char* key, int *nbyes)
{
	static char getValue[99] = "\0";
	pNode *find = pHead->next;
	while(find != NULL){
		if(strcmp(key,find->key)==0){
			strcpy(getValue,find->value);
			break;
		}
		find = find->next;
	}
	return getValue;
}
