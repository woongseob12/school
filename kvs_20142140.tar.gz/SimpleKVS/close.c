#include <stdio.h>
#include <stdlib.h>
#include "kvs.h"

extern FILE *putP, *getP;
extern pNode *pHead;

void close()
{
	pNode *pTemp, *pDel;

	fclose(putP);
	fclose(getP);
	
	pDel = pHead->next;
	while(pDel != NULL){
		pTemp = pDel->next ;
		free(pDel);
		pDel = pTemp;
	}
}
